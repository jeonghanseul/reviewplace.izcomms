<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

if (G5_IS_MOBILE) {
    include_once(G5_THEME_MOBILE_PATH.'/group.php');
    return;
}

if(!$is_admin && $group['gr_device'] == 'mobile')
    alert($group['gr_subject'].' 그룹은 모바일에서만 접근할 수 있습니다.');

$g5['title'] = $group['gr_subject'];
include_once(G5_THEME_PATH.'/head.php');
include_once(G5_LIB_PATH.'/latest.lib.php');
?>


<!-- 메인화면 최신글 시작 -->
<?php
	
if($board['bo_use_secret'] && !$is_admin) {
	if($sql_search) {
		$sql_search .= " and mb_id = '".$member['mb_id']."'";
	} else {
		$sql_search .= " and mb_id = '".$member['mb_id']."'";
	}
} else if($board['bo_use_secret'] && $is_admin == 'group') {
	if($sql_search) {
		$sql_search .= " and mb_level = '".$member['mb_level']."'";
	} else {
		$sql_search .= " and mb_level = '".$member['mb_level']."'";
	}
}
    $lt_style = "";
    if ($i%2==1) $lt_style = "margin-left:20px";
    else $lt_style = "";
?>
    <div style="width: 100%;">
    <?php
    // 이 함수가 바로 최신글을 추출하는 역할을 합니다.
    // 사용방법 : latest(스킨, 게시판아이디, 출력라인, 글자수);
    echo latest2('theme/basic', '1team_r', 100, 255);
    ?>
    </div>

<!-- 메인화면 최신글 끝 -->

<?php
include_once(G5_THEME_PATH.'/tail.php');
?>
