<?php
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

// 선택옵션으로 인해 셀합치기가 가변적으로 변함
$colspan = 6;

// add_stylesheet('css 구문', 출력순서); 숫자가 작을 수록 먼저 출력됨
add_stylesheet('<link rel="stylesheet" href="'.$board_skin_url.'/style.css">', 0);
?>
<style>
#sortable-list		{ padding:0; }
#sortable-list li	{ 
    /* padding: 4px 8px; */
    color: #1D212B;
    font-weight: bold;
    cursor: move;
    list-style: none;
    /* width: 500px; */
    background: #F2F5F9;
    margin: 10px 0;
    border: 1px solid #FBFBFB;
}

</style>
<!-- 게시판 목록 시작 { -->
<form id="dd-form" action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
<input type="hidden" value="1" name="autoSubmit" id="autoSubmit" />

<div id="bo_list" style="width:<?php echo $width; ?>">
	<div class="tbl_head01 tbl_wrap">
		<ul id="sortable-list">
		<?php
		$order = array();
		for ($i=0; $i<count($list); $i++) {
			$order[$i] = $list[$i]['wr_id'];
		?>
		<li data-title="<?=$list[$i]['wr_id']?>">
		<table>
		<tr>
			<td class="td_num"style="    color: #ED4556;">
				<?php echo $list[$i]['wr_good']; ?>
			</td>
			<td class="td_subject" style="text-align: center;">
				<?php echo $list[$i]['subject'];?>
			</td>
			<td class="td_name sv_use" style="text-align: center;">
				<span style="color: #ED4758;">(<?php echo $list[$i]['mb_level'];?>팀)</span> <?php echo $list[$i]['name'];?>
			</td>
			<td class="td_name sv_use" style="text-align: center;">
				<?php echo $list[$i]['datetime2'] ?>
			</td>
			<td class="td_name sv_use">
			
			</td>
		</tr>
		</table>
		</li>
		<?php } ?>
		</ul>
	</div>
</div>

<input type="hidden" name="sort_order" id="sort_order" value="<?php echo implode(',',$order); ?>" />
</form>
<script src="<?php echo G5_JS_URL ?>/jquery-1.8.3.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.js"></script>

<script>
<?if(IS_ADMIN == 'super') {?>
/* when the DOM is ready */
$(document).ready(function() {
	/* grab important elements */
	var sortInput = $('#sort_order');
	var submit = $('#autoSubmit');
	//var messageBox = jQuery('#message-box');
	var list = $('#sortable-list');
	/* create requesting function to avoid duplicate code */
	var request = function() {
		jQuery.ajax({
			beforeSend: function() {
			//	messageBox.text('Updating the sort order in the database.');
			},
			complete: function() {
			//	messageBox.text('Database has been updated.');
			},
			data: 'bo_table=<?php echo $bo_table?>&sort_order=' + sortInput.val() + '&ajax=' + submit.val() + '&do_submit=1&byajax=1', //need [0]?
			type: 'post',
			url: '<?php echo G5_URL; ?>/sort_ajax.php'
		});
	};
	/* worker function */
	var fnSubmit = function(save) {
		var sortOrder = '';
		list.find('li').each(function(){
			sortOrder = sortOrder + $(this).attr('data-title') + ',';
		});

		sortOrder = sortOrder.slice(0, -1);
		sortInput.val(sortOrder);

		if(save) {
			request();
		}
	};
	/* sortables */
	list.sortable({
		opacity: 0.7,
		update: function() {
			fnSubmit(submit.val());
		}
	});
	list.disableSelection();
	/* ajax form submission */
	jQuery('#dd-form').bind('submit',function(e) {
		if(e) e.preventDefault();
		fnSubmit(true);
	});
});
<?}?>
</script>