<?php
include_once('./_common.php');

$write_table = $_POST['write_table'];
$wr_10 = $_POST['wr_10'];
$wr_id = $_POST['wr_id'];

if($_POST['method'] == 'date_ok') {
	//sql_query();
	sql_query(" update ".$write_table." set wr_10 = '".$wr_10."' where wr_id = '".$wr_id."' ");
	
	echo json_encode(Array('result'=>true));
}
?>