<?
$g5_path = "../../../"; // common.php 의 상대 경로
include_once("$g5_path/common.php");
?>
