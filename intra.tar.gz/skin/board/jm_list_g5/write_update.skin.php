<?
if (!defined("_GNUBOARD_")) exit; // 개별 페이지 접근 불가 

//순서변경
if($is_admin && $insert_num && $insert_num >0) {
$insert_num--;
     $sql2 = " select wr_num, wr_datetime from $write_table where wr_is_comment = 0 order by wr_num DESC limit $insert_num, 1 ";
	 $result2 = sql_query($sql2);
	 $row2 = sql_fetch_array($result2);
   $move_wr_num= $row2[wr_num];
   $move_wr_datetime= date("Y-m-d H:i:s", strtotime($row2[wr_datetime]."+17 seconds"));

   if($w =='') $pre_wr_num= $wr_num;
   else {
     $sql3 = " select wr_num from $write_table where wr_id= '$wr_id' ";
	 $result3 = sql_query($sql3);
	 $row3 = sql_fetch_array($result3);
     $pre_wr_num= $row3[wr_num];
   }
//    echo "<br>////////////////1.m_wr_num= $move_wr_num ///pre_wr_num= $pre_wr_num";
//	exit;

   if( $move_wr_num )
	   sql_query("update $write_table set wr_num = (wr_num - 1) where wr_num<= $move_wr_num " );
   else $move_wr_num = get_next_num($write_table);

   if($move_wr_num> $pre_wr_num) $pre_wr_num--;

   sql_query("update $write_table set wr_num = $move_wr_num, wr_datetime = '$move_wr_datetime' where wr_num= '$pre_wr_num' " );

}

goto_url(G5_BBS_URL."/board.php?bo_table=$bo_table$qstr");
?>