<?
include_once("./_common.php");

//전체수정
for ($i=0; $i<$chk; $i++)
{
    $wr_id = $_POST['wr_id_up'][$i];

        $sql = " update {$write_table} set 
						 wr_subject = '$wr_subject[$i]',
						 wr_1 = '$wr_1[$i]',
						 wr_2 = '$wr_2[$i]',
						 wr_3 = '$wr_3[$i]',
						 wr_4 = '$wr_4[$i]'
                  where wr_id = '$wr_id' ";
        sql_query($sql);
}

alert("수정 되었습니다", $g4[bbs_path]."/board.php?bo_table=$bo_table$qstr");
?>
